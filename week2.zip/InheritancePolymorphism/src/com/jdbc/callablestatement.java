package com.jdbc;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Scanner;

public class callablestatement {

	public static void main(String[] args) throws SQLException, ClassNotFoundException {
		// TODO Auto-generated method stub
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","admin");
		CallableStatement cst=con.prepareCall("{ CALL square(?,?)}");
		System.out.println("enter a number:");
		Scanner sc=new Scanner(System.in);
		int a=sc.nextInt();
		cst.setInt(1,a);
		cst.registerOutParameter(2, Types.INTEGER);
		cst.execute();
		System.out.println("Result from db is:" +cst.getInt(2));

	
	}

}
