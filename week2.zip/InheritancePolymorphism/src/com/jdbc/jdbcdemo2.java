package com.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class jdbcdemo2 {

	
	public static void main(String[] args) throws SQLException, ClassNotFoundException {
		// TODO Auto-generated method stub
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","admin");

		Statement st=con.createStatement();
		PreparedStatement pst=con.prepareStatement("insert into plan values(?,?)");
		System.out.println("enter 3 plan records,id,name");
		Scanner sc=new Scanner(System.in);
		for(int i=1;i<=3;i++) {
			pst.setInt(1, sc.nextInt());
			pst.setInt(2, sc.nextInt());
			pst.execute();
		}
		ResultSet rs=st.executeQuery("select*from plan");
		ResultSetMetaData rsmd=rs.getMetaData();
		System.out.println(rsmd.getColumnCount());
		for(int i=1;i<=rsmd.getColumnCount();i++) {
			System.out.println(rsmd.getColumnName(i)+"");
			while(rs.next()) {
				System.out.println(rs.getString(1)+" "+rs.getString(2));
			}
		}
		PreparedStatement pst1=con.prepareStatement("update plan3 set name=? where pid=?");
		System.out.println("enter id for which name to update");
		Scanner sc1=new Scanner(System.in);
		
			
		
		
	}

}
