package com.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;


public class JDBCApp1 {

	
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
Class.forName("oracle.jdbc.driver.OracleDriver");
Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","admin");

System.out.println("connection success");
Statement st=con.createStatement();
//st.executeUpdate("create table plan3(pid number primary key,name varchar(20))");
//System.out.println("table created");
//st.executeUpdate("insert into plan3 values(5,'friend1')");
//st.executeUpdate("insert into plan3 values(15,'friend2')");
//st.executeUpdate("insert into plan3 values(25,'friend3')");
//st.executeUpdate("insert into plan3 values(35,'friend4')");
//st.executeUpdate("insert into plan3 values(45,'friend5')");
//st.execute("delete from plan3 where pid=5");
//st.execute("update  plan3 set name='ram' where pid=15");
//System.out.println("done");



}

}
