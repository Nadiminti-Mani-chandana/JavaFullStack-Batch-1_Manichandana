package com.verizon;

import java.util.ArrayList;
import java.util.List;

class Course{
	Integer id;
	String name;
	Double fee;
	public Course(Integer id, String name, Double fee) {
		super();
		this.id = id;
		this.name = name;
		this.fee = fee;
	}
	@Override
	public String toString() {
		return "Course [id=" + id + ", name=" + name + ", fee=" + fee + "]";
	}
	
	interface CourseService{
		String addCourse(Course c);
		String deleteCourse(Integer cid);
		String updateCourse(Integer cid);
		List<Course> listCourse();
		
	}
	
	class CourseServiceImpl implements CourseService{
		List<Course> courseList=new ArrayList<>();

		@Override
		public String addCourse(Course c) {
			// TODO Auto-generated method stub
			return "Course added successfully";
		}

		@Override
		public String deleteCourse(Integer cid) {
			// TODO Auto-generated method stub
			return "ok";
		}

		@Override
		public String updateCourse(Integer cid) {
			// TODO Auto-generated method stub
			return "ok";
		}

		@Override
		public List<Course> listCourse() {
			// TODO Auto-generated method stub
			return courseList;
		}
		
	}
}
