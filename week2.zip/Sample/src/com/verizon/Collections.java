package com.verizon;

import java.util.ArrayList;
import java.util.List;
public class Collections{
public static void main(String[] args) {
	
	
	List l=new ArrayList();
	l.add(23);
	l.add(4355,3444);
	l.add("java");
	l.add("python");
	System.out.println(l);
	System.out.println(l.size());
	
	
	
}
}
