package com.verizon;

public class calculator {

	int Sum(int a,int b) {
		return(a+b);
	}
	int Diff(int a,int b) {
		return(a+b);
	}
	int Product(int a,int b) {
		return(a+b);
	}
	int Div(int a,int b) {
		return(a+b);
	}
}
