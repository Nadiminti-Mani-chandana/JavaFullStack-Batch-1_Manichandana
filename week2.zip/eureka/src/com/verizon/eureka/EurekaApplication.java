package com.verizon.eureka;
import org.springframework.boot.springApplication;

@springApplication
@EnableEurekaServer 
public class EurekaApplication {

	publci static void main(String)

}
