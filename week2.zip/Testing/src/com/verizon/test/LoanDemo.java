package com.verizon.test;

public class LoanDemo {



	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
	}

}
