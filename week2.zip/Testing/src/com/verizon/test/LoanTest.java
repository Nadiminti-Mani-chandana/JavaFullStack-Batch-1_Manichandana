package com.verizon.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class LoanTest {

	@Test
	void testSum() {
		fail("Not yet implemented");
	}

	@Test
	void testDiff() {
		fail("Not yet implemented");
	}

	@Test
	void testProduct() {
		fail("Not yet implemented");
	}

	@Test
	void testDiv() {
		fail("Not yet implemented");
	}

}
