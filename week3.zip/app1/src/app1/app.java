package app1;

import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import junit.framework.Assert;

public class app{
	WebDriver driver;
	@Test
	public void verifyTitle() {
		driver=new ChromeDriver();
		driver.get("https://www.google.com/");
		Assert.assertEquals(driver.getTitle(), "App & Cross Browser Testing Platform | BrowserStack");
		driver.quit();
	}
}
