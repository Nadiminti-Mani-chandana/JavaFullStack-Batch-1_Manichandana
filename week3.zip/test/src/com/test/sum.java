package com.test;

public class sum {

	public int addNum() {
		int a=1;
		int b=2;
		return(a+b);
	}
}
