package com.test.test1;

import org.testng.annotations.Test;

public class sumTest {
  @Test
  public void addNumTest() {
	  System.out.println("The sum of the two integers is 3");
  }
  @Test(priority=-8)
  public void sample() {
	  System.out.println("Test with priority -8");
  }
  @Test(priority=10)
  public void sample1() {
	  System.out.println("Test with priority 10 aaaa");
}
  
  @Test(priority=10)
  public void sample2() {
	  System.out.println("Test with priority 10 bbbb");
}
  @Test
  public void sample5() {
	  System.out.println("Test with priority 0");
  
  }
}


