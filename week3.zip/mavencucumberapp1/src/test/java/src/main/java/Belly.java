package src.main.java;

public class Belly {

public void eat(int cakes) {
	System.out.println("step started");
}
public void waitstep() {
	System.out.println("waiting after step1");
}
public void endProcess() {
	System.out.println("all steps completed");
}

}
