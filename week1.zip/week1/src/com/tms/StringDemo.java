package com.tms;
import java.util.Scanner;
import java.util.StringTokenizer;

public class StringDemo {

	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
/*String name ="verizon developer";
String name123 ="verizon developer";
String name1 = new String("Java developer");

System.out.println(name.length());
System.out.println(name.toLowerCase());
System.out.println(name.charAt(2));
System.out.println(name.concat("hyd"));
name.replace('e','f');
System.out.println(name.indexOf("e"));
System.out.println(name.lastIndexOf("e"));
System.out.println(name.compareTo(name123));
System.out.println(name.equals(name123));
System.out.println(name==name123);
char city[]= {'h','y','d'};
String citys=new String(city);

Scanner sc =new Scanner(System.in);
String comments=sc.nextLine();
System.out.println(comments);
String tokens[]=comments.split(" ");

for (int i=0;i<tokens.length;i++)
	System.out.println(tokens[i]);
//enhanced for loop
for(String x:tokens)
	System.out.println(x);*/
String ss="javatechnolgy";
StringBuilder sb=new StringBuilder(ss);
String sss=sb.toString();

System.out.println(sb.capacity());
sb.append(1999);
System.out.println(sb);
System.out.println(sb.insert(3, "xxxx"));
sb.ensureCapacity(50);
System.out.println(sb.capacity());
System.out.println(sb.delete(3,8));
System.out.println(sb.reverse());


String line= "verizon,Buildingno10,Raheja mindspace, hyderabad, telangana";
StringTokenizer st = new StringTokenizer(line,"  ");
System.out.println(st.countTokens());
while(st.hasMoreTokens())
	System.out.println(st.nextToken());
	




	}

}
