package com.verizon;

public class Demo {

	

	public static void main(String[] args) 
	
	{
		System.out.println(args[0]+"Welcome to Java");
		System.out.println(args[1]+"Welcome to python");
		
	}

}

