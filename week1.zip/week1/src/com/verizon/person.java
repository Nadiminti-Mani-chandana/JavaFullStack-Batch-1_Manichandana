package com.verizon;

public class person {
	int id;
	String name;
	person(){
		System.out.println("in parent");
		
	}

	public person(int id,String name) {
		// TODO Auto-generated constructor stub
		this.id=id;
		this.name=name;
		System.out.println("parameterized const "+this.id+ " "+this.name);
	}

}

