package com.verizon;

public class Account {
int acNumber;
String name;
double balance;
Account()
{
	acNumber=999;
	name="Bankuser";
	balance=1000.00;
}

Account(int acNumber,String name,double balance){
	this.acNumber=acNumber;
	this.name=name;
	this.balance=balance;
}

void deposit(int amt) {
	balance+=amt;
}
double withdraw(int amt) {
	balance-=amt;
	return balance;
}
double getBalance() {
	return balance;
	
}
public static void main(String[] args) {
	
}
}
