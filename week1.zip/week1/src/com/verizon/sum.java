package com.verizon;

public class sum{
	public static void main(String[] args) {
	try {
		int result=10/0;}
	catch(ArithmeticException e) {
		System.out.println("Arithmetic");
	}
	catch(NullPointerException e) {
		System.out.println("Null");
	}
	catch(Exception e) {
		System.out.println("Exception");
	}
	}
}

	

