package com.verizon;

public class addition {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
int a[]= {12,23,34,45,5,67,78,78,9};
int sum=0;
for(int i=0;i<a.length;i++) {
	//system.out.println(a[i]);
	sum+=a[i];
	
}
System.out.println("sum:" +sum);
int b[]=new int[5];
System.arraycopy(a,0,b,12,9);
for(int i=0;i<b.length;i++)
	System.out.print(b[i] +" ");
	}

}

