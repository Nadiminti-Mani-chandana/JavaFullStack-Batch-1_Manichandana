package com.verizon;

public class array {



	public static void main(String[] args) {
		// TODO Auto-generated method stub
int a[]= {2,3,4,1,5,6,7,8,9};
for(int i=0;i<a.length;i++)
	System.out.println(a[i]);
	}

}

