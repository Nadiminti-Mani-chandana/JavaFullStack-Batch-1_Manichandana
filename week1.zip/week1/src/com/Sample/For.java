package com.verizon.Sample;
public class For {
public static void main(String[] args) {
// TODO Auto-generated method stub
String s1[]=new String []{"we","Welcome","you"};
for(String y:s1)
{
System.out.println(y);
}
}
}
