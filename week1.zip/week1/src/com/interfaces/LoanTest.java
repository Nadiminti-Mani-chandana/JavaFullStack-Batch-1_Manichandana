package com.tms.interfaces;


public interface LoanTest {

	public static void main(String[] args) {
		Loan l;
		HousingLoan h1=new HousingLoan();
		l=h1;
        l=new HousingLoan();
		l.applyLoan("ram",2000000.00);
		l.submitDocs();
		System.out.println(l.getEmi());
		surity hl = null;
		surity s1=hl;
		s1.submitDocs2();
		vehicleLoan v1=new vehicleLoan();
		l=h1;
        l=new vehicleLoan();
		l.applyLoan("ram1",8000000.00);
		l.submitDocs();
		System.out.println(l.getEmi());
				
		
		
		
	}
	
	
}
