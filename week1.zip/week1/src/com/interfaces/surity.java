package com.tms.interfaces;

public class surity {

	void submitDocs2() {
		// TODO Auto-generated method stub
		
	}

	void submitDocs21() {
		// TODO Auto-generated method stub
		
	}

	}

