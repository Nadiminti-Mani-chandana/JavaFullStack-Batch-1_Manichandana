package com.tms.interfaces;

public abstract class vehicleLoan implements Loan {

	public void applyLoan(String name,double amount)
	{
		System.out.println(name +"loan of amount Rs"+amount+"applied");
	}
	public void submitDocs(){
		System.out.println("docs are submitted");
		}
	public int getEmivehicle() {
		return 999;
	}
}
