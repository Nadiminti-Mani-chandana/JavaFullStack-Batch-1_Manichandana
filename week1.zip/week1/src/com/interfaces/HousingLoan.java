package com.tms.interfaces;

import com.tms.interfaces.Loan;

public class HousingLoan implements Loan {

	public void applyLoan(String name,double amount)
	{
		System.out.println(name +"loan of amount Rs"+amount+"applied");
	}
	public void submitDocs(){
		System.out.println("docs are submitted");
		}
	public int getEmi() {
		return 999;
	}
}
