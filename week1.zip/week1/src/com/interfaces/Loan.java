package com.tms.interfaces;

public interface Loan {
 
	 public void applyLoan(String name,double amount);
	public void submitDocs();
	public int getEmi();
	
	
}
