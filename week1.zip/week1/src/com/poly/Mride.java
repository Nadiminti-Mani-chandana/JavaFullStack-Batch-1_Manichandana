package com.verizon.poly;

public class Mride {

	void sq(int s) {
		System.out.println("perimeter of sq:" +(4*s));
	}
	public static void main(String[] args) {
		Mride m=new Mride();
		m.sq(4);
		Ride r=new Ride();
		r.sq(4);
		r=new Ride();
		r.sq(4);
	}
	
}

