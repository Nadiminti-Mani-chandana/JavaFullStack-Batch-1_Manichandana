package com.verizon.poly;

public class Mride1 {

	void sq(int s) {
		System.out.println("cube:" +(s*s*s));
	}
	public static void main(String[] args) {
	Mride m= new Mride();
	m.sq(4);

}
}
