package com.tms.java8;

import java.util.Random;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;

public class FunctionalDemo3 {


	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Consumer<Integer> con1=(a)->System.out.println("Square of the given number:" +(a*a));
		con1.accept(3);
		
		
		Supplier<Integer> s1=()->new Random().nextInt(100);
		System.out.println(s1.get());
		
		Predicate<Integer> p=(a)->a%2==0;
		System.out.println(p.test(8));
		System.out.println(p.test(15));
		System.out.println(p.test(16));
		System.out.println(p.test(85));
		
		
		Function<Integer,Integer> f1=(a)->a*a*a;
		System.out.println(f1.apply(5));
		
		Function<String,Integer> f2=(s)->Integer.parseInt(s);
		System.out.println(f2.apply("20"));
		
		
	}

}

