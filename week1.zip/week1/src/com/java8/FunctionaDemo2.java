package com.tms.java8;

import java.util.function.Consumer;

public class FunctionaDemo2 {


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Consumer<Integer> consumer=(a)->System.out.println("Square of number:"+(a*a));
consumer.accept(3);

Consumer<Double> consumer1=(a)->System.out.println("Discount 10%:"+(a*0.10));
consumer1.accept(450000.000);


	}

}

