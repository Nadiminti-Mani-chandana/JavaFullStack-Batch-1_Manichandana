package com.tms.java8;
@FunctionalInterface
interface Arith{
	int getsum(int a,int b);
}
public class FunctionDemo {
int getsum(int a,int b) {
	return a+b;
}
public static void main(String[] args) {
	FunctionDemo f1=new FunctionDemo();
	int result = f1.getsum(2,4);
	System.out.println(result);
}




}
