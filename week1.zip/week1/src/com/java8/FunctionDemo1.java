package com.tms.java8;
@FunctionalInterface
interface Arith1<T>{
	T op(T a,T b);
}
public class FunctionDemo1 {
public static void main (String[] args) {
	Arith1 <Integer>arith=(a,b)->{int c=a+b;return c;};
	System.out.println(arith.op(5, 6));
	
	
	Arith1 <Double>arith1=(a,b)->a*a+b*b;
	System.out.println(arith1.op(4.788, 6.9));
	
	Arith1 <Float> arith2=(a,b)->a-a+b*b;
	System.out.println(arith2.op(8f, 6f));
}

	
}

