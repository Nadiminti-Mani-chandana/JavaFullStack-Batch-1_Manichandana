package com.tms.java8;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

public class Stream {

public static void main(String[] args) {
	
	
	List<Integer> list=Arrays.asList(21,23,222,45,23,67,45,234,67,43,23,11,23,100,34,23,14,23,12,23,23,43,32,54,65,67,89,23,45,5690,56,23,5,2,6,2,6);
	list.forEach(x->System.out.println(x+" "));
	
	System.out.println();
	list.stream().sorted().filter(x->x<=5).limit(8).forEach(x->System.out.print(x+ " "));
	System.out.println();
	
	list.stream().sorted().filter(x->x<=100).forEach(x->System.out.println(x+ ""));
	System.out.println();
	
	
	
	
	Optional<Integer> max=list.stream().sorted(Collections.reverseOrder()).skip(1).findFirst();
	if(max.isPresent())
		System.out.println("Max:"+max.get());

	
	String s=null;
	Optional<String> s1=Optional.ofNullable(null);
	if(s1.isPresent())
		System.out.println(s1.get());
	else
		System.out.println("Empty");
	
	
}


}
