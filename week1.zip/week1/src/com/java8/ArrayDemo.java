package com.tms.java8;

import java.util.Arrays;
import java.util.List;

public class ArrayDemo {

	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int a[]= {4,5,6,3,45,6,7,7};
		
		for(int x:a)
			System.out.println(x+" ");
		Arrays.sort(a);
		System.out.println();
		
		
		for(int x:a)
			System.out.println(x+" ");
		System.out.println();
		 
		int b[]=new int[5];
		Arrays.fill(b,89);
		for(int x:b)
			System.out.println(x+" ");
		System.out.println(Arrays.compare(a, b));
		
		
		
		List<Integer> list1=Arrays.asList(2,4,56,78,54,3,4,5,43,2,3,3);
		System.out.println("=========forEach method with lambda========");
		list1.forEach(x->System.out.println(x));
		
		
		System.out.println("=======forEach method with method reference=====");
	 list1.forEach(System.out::println);
		
		}

}

