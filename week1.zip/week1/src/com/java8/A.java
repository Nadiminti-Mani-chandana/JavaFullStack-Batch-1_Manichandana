package com.tms.java8;

public class A {
public static String line="This is my Program";
static
{
System.out.println("Welcome to Java");
System.exit(0);
}
public void display()
{
System.out.println("begin:");
}
public static void main(String[] args) {
System.out.println("Program starts here");
A object=new A();
object.display();
System.out.println(A.line);
}
}

