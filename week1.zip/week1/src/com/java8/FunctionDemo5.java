package com.tms.java8;

import java.util.StringJoiner;

public class FunctionDemo5 {

	
	public static void main(String[] args) {
		StringJoiner joinNames =new StringJoiner(",");
		joinNames.add("Rahul");
		joinNames.add("Rahul1");
		joinNames.add("Rahul2");
		joinNames.add("Rahul3");
		
		System.out.println(joinNames);
		System.out.println(joinNames.length());
		StringJoiner s1=new StringJoiner("-");
		s1.add("java");
		s1.add("python");
		System.out.println(joinNames.merge(s1));
				
	}
	}



