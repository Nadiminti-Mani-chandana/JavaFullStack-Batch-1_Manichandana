package com.inheritance;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

public class collection {

		public static void main(String[] args) {
		// TODO Auto-generated method stub
Set <String> names=new TreeSet();
names.add("ram");
names.add("akhil");
names.add("kiran");
names.add("bindu");
names.add("bindu");
System.out.println(names);













	}

}
