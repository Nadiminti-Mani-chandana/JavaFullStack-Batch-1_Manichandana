package counter;

public class DepositException extends Exception {

	DepositException(String msg){
	}

}

