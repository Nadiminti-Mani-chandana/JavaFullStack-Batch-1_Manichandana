package counter;

import java.io.FileNotFoundException;
import java.io.FileReader;

public class Ex5 {

public static void show() throws FileNotFoundException,InterruptedException
{
	FileReader f=new FileReader("c:\\abc.txt");
	Thread.sleep(5000);
}
public static void main(String[] args) throws FileNotFoundException,InterruptedException{
	Ex5 e1=new Ex5();
	e1.show();
	System.out.println("done");
}

}
