package counter;

public class Ex6 {

	

	public static void main(String[] args) throws DepositException {
		// TODO Auto-generated method stub
		int amt=999;
		if(amt<1000)
			throw new DepositException("minimum amount is 1000/-");
		else
			System.out.println("Thank ");

	}

}

