package com.verizon.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.verizon.model.Customer;
import com.verizon.service.CustomerService;
@RestController
public class CustomerController {
	
	@Autowired
	CustomerService customerService;
	@GetMapping("/customers")
	public ResponseEntity<List<Customer>> getAllCustomers() {  // need to implement
		//
		//List<Customer> customerList=new ArrayList<>();  //sample list need to replace
		//
		return new ResponseEntity<>(customerService.getAllCustomers(), HttpStatus.OK);
	}

	
	  @PostMapping("/customer") 
	  public ResponseEntity<Customer>  addCustomer(@RequestBody  Customer customer) { // need to implement
		   //
		  return  new ResponseEntity<>(customerService.addCustomer(customer), HttpStatus.CREATED);
	 
	  }
	
	@PutMapping("/customer/{cid}") 
	public ResponseEntity<Customer> updateCustomer(@PathVariable("cid") Integer cid,@RequestBody Customer customer) {
		 return new ResponseEntity<>(customerService.updateCustomer(cid, customer.getCname(), customer.getEmail()), HttpStatus.OK);
	}
	
	@DeleteMapping("/customer/{cid}") 
	public ResponseEntity<String> deleteCustomer(@PathVariable("cid") Integer cid) {
		customerService.deleteCustomer(cid);
		return new ResponseEntity<>("Success", HttpStatus.OK);
	}
}
